package com.example.bloodmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodmanagerApplication.class, args);
	}

}
